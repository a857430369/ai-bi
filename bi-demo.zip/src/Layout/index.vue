<template>
  <div>
    <router-link to="/config">
      <vxe-button>配置</vxe-button>
    </router-link>
    <router-link to="/main">
      <vxe-button>渲染</vxe-button>
    </router-link>
  </div>
</template>